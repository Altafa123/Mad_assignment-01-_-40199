package com.example.mad_40199_ass1;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
