import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, // Remove the debug banner
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            MaximumBid(),
          ],
        ),
      ),
    );
  }
}

class MaximumBid extends StatefulWidget {
  @override
  _MaximumBidState createState() => _MaximumBidState();
}

class _MaximumBidState extends State<MaximumBid> {
  double _maxBid = 500.0; // Set the starting bid to $500

  void _increaseMyMaxBid() {
    setState(() {
      _maxBid += 50.0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        ElevatedButton(
          onPressed: _increaseMyMaxBid,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blue, // Change the button's background color
            shape: RoundedRectangleBorder(), // Makes the button square
            fixedSize: const Size(50, 50), // Square button size
          ),
          child: const Icon(
            Icons.add,
            color: Colors.white, // Change the color of the + icon
          ),
        ),
        const SizedBox(width: 20),
        Text(
          'My Maximum Bid: \$$_maxBid',
          style: Theme.of(context).textTheme.headlineMedium,
        ),
      ],
    );
  }
}

